<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="/js/packages.js"></script>
<link href="/css/packages.css" rel="stylesheet" />
<div class="container">
    <div class="row">
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($title); ?></div>
                <div class="panel-body">
                <?php if(isset($package)): ?>
                    <?php echo Form::model($package, array('url' => ['packages/save', $package->id], 'class' => 'form-horizontal', 'role' => 'form')); ?>

                <?php else: ?>
                    <?php echo Form::open(['url' => ['packages/save'], 'class' => 'form-horizontal', 'role' => 'form']); ?>

                <?php endif; ?>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('name', 'Nombre', array('class' => 'col-md-3 control-label')); ?>

                            <div class="col-md-7">
                            <?php echo Form::text('name', null, array('class' => 'form-control', 'required' => 'required', 'autofocus' => 'autofocus')); ?>


                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('description', 'Descripción', array('class' => 'col-md-3 control-label')); ?>


                            <div class="col-md-7">
                                <?php echo Form::text('description', null, array('class' => 'form-control', 'required' => 'required')); ?>


                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('package_price') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('package_price', 'Precio', array('class' => 'col-md-3 control-label')); ?>


                            <div class="col-md-7">
                                <?php echo Form::number('package_price', null, array('class' => 'form-control', 'required' => 'required', 'step' => '.5')); ?>


                                <?php if($errors->has('package_price')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('package_price')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('category_id', 'Categoría', array('class' => 'col-md-3 control-label')); ?>


                            <div class="col-md-7">
                                <?php echo Form::select('category_id', $category_options, null, ['class' => 'form-control select2']); ?>


                                <?php if($errors->has('category_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('category_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <?php echo Form::label('products', 'Productos', array('class' => 'col-md-3 control-label')); ?>

                            <div class="col-md-7 form-inline">
                                
                                <?php echo Form::select(null, $product_options, null, ['id' => 'productSelect', 'class' => 'form-control select2 col-md-4']); ?>

                            </div>
                            <?php echo Form::button('Añadir', array('id' => 'productAddBtn', 'class' => 'btn btn-default')); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('product') ? ' has-error' : ''); ?>">
                            <div class="well text-center" style="margin: 10px;">
                                <strong id="noProductsSpan">No se han agregado productos.</strong>
                                <table id="itemsTable">
                                    <tr>
                                        <th>Cantidad</th>
                                        <th>Producto</th>
                                        <th></th>
                                    </tr>
                                    <?php if(isset($package)): ?> 
                                    <?php $__currentLoopData = $package->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr class="itemRow">
                                        <td><input type="number" name="product[<?php echo e($index); ?>][qty]" min="1" value="<?php echo e($product->pivot->qty); ?>"class="input-xsmall" style="" /></td>
                                        <td><input type="hidden" name="product[<?php echo e($index); ?>][id]" value="<?php echo e($product->id); ?>" /><?php echo e($product->name); ?></td>
                                        <td><a href="javascript:void(0);"><img src="/images/delete.png"/></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <?php endif; ?>
                                </table>
                            </div>
                            <?php if($errors->has('product')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('product')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-froup">
                            <div class="col-md-7 col-md-offset-3">
                            <?php if(!isset($package)): ?>
                                <?php echo Form::checkbox('published', '1', true); ?>

                            <?php else: ?>
                                <?php echo Form::checkbox('published', '1'); ?>

                            <?php endif; ?>
                                <?php echo Form::label('published', 'Publicado'); ?>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-7 col-md-offset-3">
                                <?php echo Form::submit($submitText, array('class' => 'btn btn-primary')); ?>

                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>