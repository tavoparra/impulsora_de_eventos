<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Detalle de usuario</div>
                <div class="panel-body">
                    <?php echo Form::model($user, array('url' => ['users/save', $user->id], 'class' => 'form-horizontal', 'role' => 'form')); ?>

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('name', 'Nombre', array('class' => 'col-md-4 control-label')); ?>

                            <div class="col-md-6">
                            <?php echo Form::text('name', null, array('class' => 'form-control', 'required' => 'required', 'autofocus' => 'autofocus')); ?>


                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('username', 'Nombre de usuario', array('class' => 'col-md-4 control-label')); ?>


                            <div class="col-md-6">
                                <?php echo Form::text('username', null, array('class' => 'form-control', 'required' => 'required')); ?>


                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('email', 'Correo electrónico', array('class' => 'col-md-4 control-label')); ?>


                            <div class="col-md-6">
                                <?php echo Form::email('email', null, array('class' => 'form-control', 'required' => 'required')); ?>


                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <?php echo Form::label('', 'Permisos', array('class' => 'col-md-4 control-label')); ?>


                            <div class="col-md-6">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php echo Form::checkbox('roles[]', $rol->slug, $user->hasRole($rol->slug))." ".$rol->description; ?><br/>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <?php echo Form::submit('Actualizar', array('class' => 'btn btn-primary')); ?>

                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>