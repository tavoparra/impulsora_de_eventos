<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="/js/reservations.js"></script>
<link href="/css/reservations.css" rel="stylesheet" />
<div class="container">
    <div class="row">
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($title); ?></div>
                <div class="panel-body">
                <?php if(isset($reservation)): ?>
                    <?php echo Form::model($reservation, array('url' => ['reservations/save', $reservation->id], 'class' => 'form-horizontal', 'role' => 'form')); ?>

                <?php else: ?>
                    <?php echo Form::open(['url' => ['reservations/save'], 'class' => 'form-horizontal', 'role' => 'form']); ?>

                <?php endif; ?>
                        <div class="form-group<?php echo e($errors->has('date') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('date', 'Fecha', array('class' => 'col-md-3 control-label')); ?>

                            <div class="col-md-7">
                            <?php echo Form::text('date', null, array('class' => 'form-control', 'required' => 'required', 'id' => 'reservation_date')); ?>


                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('date')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('location', 'Ubicación', array('class' => 'col-md-3 control-label')); ?>


                            <div class="col-md-7">
                                <?php echo Form::text('location', null, array('class' => 'form-control', 'required' => 'required')); ?>


                                <?php if($errors->has('location')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('location')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('customer') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('customer', 'Cliente', array('class' => 'col-md-3 control-label')); ?>


                            <div class="col-md-7">
                                <?php echo Form::textarea('customer', null, array('class' => 'form-control', 'required' => 'required', 'rows' => '4')); ?>


                                <?php if($errors->has('customer')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('customer')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <?php echo Form::label('products', 'Productos', array('class' => 'col-md-3 control-label')); ?>

                            <div class="col-md-7 form-inline">
                                
                                <select id="productSelect" class="form-control select2 col-md-4">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option
                                            value="<?php echo e($product->id); ?>"
                                            data-price="<?php echo e($product->unit_price); ?>"
                                            >
                                            <?php echo e($product->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </select>
                            </div>
                            <?php echo Form::button('Añadir', array('id' => 'productAddBtn', 'class' => 'btn btn-default')); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('packages', 'Paquetes', array('class' => 'col-md-3 control-label')); ?>

                            <div class="col-md-7 form-inline">
                                
                                <select id="packageSelect" class="form-control select2 col-md-4">
                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option
                                            value="<?php echo e($package->id); ?>"
                                            data-price="<?php echo e($package->package_price); ?>"
                                            data-content="<?php echo e($package->content); ?>"
                                            >
                                            <?php echo e($package->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </select>
                            </div>
                            <?php echo Form::button('Añadir', array('id' => 'packageAddBtn', 'class' => 'btn btn-default')); ?>

                        </div>

                        <div class="form-group">
                            <div class="well text-center" style="margin: 10px;">
                                <strong id="noProductsSpan">No se han agregado productos.</strong>
                                <table id="itemsTable">
                                    <tr>
                                        <th>Cantidad</th>
                                        <th>Producto</th>
                                        <th>Precio</th>
                                        <th></th>
                                    </tr>
                                    <?php if(isset($reservation)): ?> 
                                    <?php $__currentLoopData = $reservation->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr class="itemRow">
                                        <td><input type="number" name="package[<?php echo e($index); ?>][qty]" min="1" value="<?php echo e($package->pivot->rented_qty); ?>"class="input-xsmall pQty" /></td>
                                        <td><input type="hidden" name="package[<?php echo e($index); ?>][id]" value="<?php echo e($package->id); ?>" /><?php echo e($package->name); ?></td>
                                        <td>$<span class="price"><?php echo e($package->package_price); ?></span></td>
                                        <td><a href="javascript:void(0);"><img src="/images/delete.png"/></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <?php $__currentLoopData = $reservation->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr class="itemRow">
                                        <td><input type="number" name="product[<?php echo e($index); ?>][qty]" min="1" value="<?php echo e($product->pivot->rented_qty); ?>"class="input-xsmall pQty" /></td>
                                        <td><input type="hidden" name="product[<?php echo e($index); ?>][id]" value="<?php echo e($product->id); ?>" /><?php echo e($product->name); ?></td>
                                        <td>$<span class="price"><?php echo e($product->unit_price); ?></span></td>
                                        <td><a href="javascript:void(0);"><img src="/images/delete.png"/></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('total') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('total', 'Total', array('class' => 'col-md-3 control-label')); ?>


                            <div class="col-md-7">
                                <?php echo Form::text('total', null, array('class' => 'form-control', 'id' => 'total', 'required' => 'required', 'rows' => '4')); ?>


                                <?php if($errors->has('total')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('total')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-7 col-md-offset-3">
                                <?php echo Form::submit($submitText, array('class' => 'btn btn-primary')); ?>

                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
    <script type="text/javascript">
        $('#reservation_date').datepicker({
           format: 'yyyy-mm-dd'
         });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>