<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($title); ?></div>
                <div class="panel-body">
                <?php if(isset($product)): ?>
                    <?php echo Form::model($product, array('url' => ['products/save', $product->id], 'class' => 'form-horizontal', 'role' => 'form')); ?>

                <?php else: ?>
                    <?php echo Form::open(['url' => ['products/save'], 'class' => 'form-horizontal', 'role' => 'form']); ?>

                <?php endif; ?>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('name', 'Nombre', array('class' => 'col-md-4 control-label')); ?>

                            <div class="col-md-6">
                            <?php echo Form::text('name', null, array('class' => 'form-control', 'required' => 'required', 'autofocus' => 'autofocus')); ?>


                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('description', 'Descripción', array('class' => 'col-md-4 control-label')); ?>


                            <div class="col-md-6">
                                <?php echo Form::text('description', null, array('class' => 'form-control', 'required' => 'required')); ?>


                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('quantity', 'Cantidad disponible', array('class' => 'col-md-4 control-label')); ?>


                            <div class="col-md-6">
                                <?php echo Form::number('quantity', null, array('class' => 'form-control', 'required' => 'required')); ?>


                                <?php if($errors->has('quantity')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('quantity')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('unit_price') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('unit_price', 'Precio unitario', array('class' => 'col-md-4 control-label')); ?>


                            <div class="col-md-6">
                                <?php echo Form::number('unit_price', null, array('class' => 'form-control', 'required' => 'required', 'step' => '.5')); ?>


                                <?php if($errors->has('unit_price')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('unit_price')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('category_id', 'Categoría', array('class' => 'col-md-4 control-label')); ?>


                            <div class="col-md-6">
                                <?php echo Form::select('category_id', $category_options, null, ['class' => 'form-control select2']); ?>


                                <?php if($errors->has('category_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('category_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-froup">
                            <div class="col-md-7 col-md-offset-3">
                            <?php if(!isset($product)): ?>
                                <?php echo Form::checkbox('published', '1', true); ?>

                            <?php else: ?>
                                <?php echo Form::checkbox('published', '1'); ?>

                            <?php endif; ?>
                                <?php echo Form::label('published', 'Publicado'); ?>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <?php echo Form::submit($submitText, array('class' => 'btn btn-primary')); ?>

                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>