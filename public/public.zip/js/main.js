$(document).ready(function () {
	// inicializamos el plugin
	$('.select2').select2({
		language: "es"
	});
});
